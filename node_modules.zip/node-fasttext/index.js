'use strict';

let FastText = require('bindings')('node-fasttext');

module.exports = FastText;